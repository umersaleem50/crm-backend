exports.navLinks = [
  { text: "Home", href: "/" },
  { text: "Team", href: "/team" },
  { text: "Community", href: "/market" },
  { text: "Feeds", href: "/feeds" },
];
