export const branches = [
  { title: "Departments" },
  { title: "Branches" },
  { title: "Admins" },
];

export const taskPriorities = [
  { title: "Important" },
  { title: "Un-Important" },
  { title: "Critical" },
];

export const serviceType = [{ title: "service" }, { title: "product" }];
