const permissions = ["have-team", "update-account", "can-post", "market-place"];

module.exports = permissions;
