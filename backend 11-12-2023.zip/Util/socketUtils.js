exports.socketEvents = {
  createConnection: "connection",
  receiveMessage: "receive-message",
  sendMessage: "send-message",
  addUser: "add-user",
};
