const profession = [
  "painter",
  "developer",
  "constructor",
  "broker",
  "electricion",
  "contractor",
  "builder",
];

module.exports = profession;
