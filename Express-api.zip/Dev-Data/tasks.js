const DEV_TASK_TYPE = ["important", "critical", "un-important"];

module.exports = { DEV_TASK_TYPE };
